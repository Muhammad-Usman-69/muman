/** @type {import('tailwindcss/tailwind.css').Config} */
module.exports = {
  content: [
    "index.html",
    "script.js",
    "product/1.html",
    "product/product.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

